from flask_sqlalchemy import SQLAlchemy

# pip install flask-sqlalchemy
# Initialize the Flask-SQLAlchemy extension instance
db = SQLAlchemy()