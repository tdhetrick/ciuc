# ciuc

This project is my senior design project for my undergraduate degree at UNCC The objective is to create a tool to allow teachers to verify if students are coding within expected patters in an efforts to reduce academic integrity issues. This is a client server application with the client being IDE plugins. There is a VS Code extension and a Chrome Browser extension. The backend server is python/flask based.




